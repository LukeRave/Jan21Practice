import UIKit

var greeting = "Hello, playground"

protocol Completed {
    mutating func complete(done: Bool)
}

struct toDoList: Completed {
    var taskName: String
    var dueBy: Date
    var action: String
    var done: Bool
    init(taskName: String, dueBy: Date, action: String, done: Bool) {
        self.taskName = taskName
        self.dueBy = dueBy
        self.action = action
        self.done = done
    }
    mutating func complete(done: Bool) {
        self.done = done
    }
}

let dateAsString = "01/22/22, 18:00"
let dateFormatter = DateFormatter()
dateFormatter.dateFormat = "M/d/yyyy, H:mm"
let date = dateFormatter.date(from: dateAsString)

var CamsToDoList = toDoList(taskName: "Clean Up", dueBy: date ?? date!, action: "Mopping", done: false)

print(CamsToDoList)

CamsToDoList.done = true
print(CamsToDoList)

let dateString = "02/12/15, 16:48"
let date2 = dateFormatter.date(from: dateString)

var MattsToDoList = toDoList(taskName: "Buy Flashcards", dueBy: date2 ?? date2!, action: "Shopping at Staples", done: false)
print(MattsToDoList)

var arrOfLists = [CamsToDoList, MattsToDoList]

for list in arrOfLists {
    print(list)
}
